# Mercadologia UERR — Quiz + Simulação (Vite + React)

Este repositório contém o app pronto para deploy.

## Rodar localmente
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Publicar na Vercel (recomendado)
1. Crie **um repositório no GitHub** e suba estes arquivos.
2. Acesse **https://vercel.com/new** → *Add New… Project* → *Import Git Repository* → Selecione seu repositório → **Deploy**.
3. Framework preset: **Vite** (detectado automaticamente).

> O app usa `localStorage` para o ranking (cada aluno vê o próprio). Para ranking compartilhado, use um backend (Supabase/Firestore).

