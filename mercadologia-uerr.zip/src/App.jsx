import React, { useMemo, useState } from "react";

// Versão reduzida – Game Interativo de Mercadologia UERR
// Inclui Quiz simplificado + Simulação 4Ps + Ranking + Exportar CSV + Testes rápidos

// ------------------------------ Util ------------------------------
function downloadText(filename, text) {
  const el = document.createElement("a");
  el.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(text));
  el.setAttribute("download", filename);
  el.style.display = "none";
  document.body.appendChild(el);
  el.click();
  document.body.removeChild(el);
}

// ------------------------------ Banco de Questões ------------------------------
const QUIZ_BANK = {
  U1: [
    {
      id: "u1q1",
      prompt: "Necessidade, desejo e demanda são:",
      options: [
        "Necessidade é cultural; desejo é biológico.",
        "Necessidade = carência básica; Desejo = cultural; Demanda = desejo + poder de compra.",
        "Necessidade sempre criada pelo marketing.",
        "Necessidade e desejo são iguais; demanda depende só do preço.",
      ],
      correctIndex: 1,
      explain: "Necessidade = básica; Desejo = cultural; Demanda = desejo + poder de compra.",
    },
  ],
};

// ------------------------------ Simulação Simplificada ------------------------------
function computeResult({ quality, price }) {
  const demand = Math.round(100 + (quality - 50) * 0.5 - (price - 2) * 20);
  const revenue = demand * (price === 1 ? 50 : price === 2 ? 80 : 120);
  return { demand, revenue };
}

// ------------------------------ Componentes Básicos ------------------------------
const Card = ({ children }) => <div className="rounded-xl shadow border p-3 bg-white">{children}</div>;
const Button = ({ children, onClick }) => <button className="px-3 py-1 rounded bg-indigo-600 text-white" onClick={onClick}>{children}</button>;

// ------------------------------ Quiz ------------------------------
function Quiz() {
  const bank = QUIZ_BANK.U1;
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState(null);
  const [show, setShow] = useState(false);
  const q = bank[idx];

  function submit() {
    if (selected == null) return;
    if (selected === q.correctIndex) setScore(score + 1);
    setShow(true);
  }
  function next() { setIdx(idx + 1); setSelected(null); setShow(false); }

  if (idx >= bank.length) return <Card>Fim do Quiz! Acertos: {score}/{bank.length}</Card>;

  return (
    <Card>
      <p className="font-bold mb-2">{q.prompt}</p>
      {q.options.map((o, i) => (
        <label key={i} className="block">
          <input type="radio" checked={selected===i} onChange={()=>setSelected(i)} /> {o}
        </label>
      ))}
      {!show && <Button onClick={submit}>Confirmar</Button>}
      {show && (
        <div>
          <p>{selected===q.correctIndex?"✔ Correto":"✖ Errado"} – {q.explain}</p>
          <Button onClick={next}>Próxima</Button>
        </div>
      )}
    </Card>
  );
}

// ------------------------------ Simulação ------------------------------
function Simulacao() {
  const [quality, setQuality] = useState(70);
  const [price, setPrice] = useState(2);
  const [nome, setNome] = useState("");
  const r = useMemo(()=>computeResult({quality,price}),[quality,price]);

  function salvar() {
    if (!nome.trim()) return alert("Informe o nome");
    const prev = JSON.parse(localStorage.getItem("ranking")||"[]");
    const rec = { id:Date.now(), nome, qualidade: quality, preco: price, ...r };
    const next = [rec, ...prev];
    localStorage.setItem("ranking", JSON.stringify(next));
    alert("Salvo no ranking!");
  }

  return (
    <Card>
      <h3 className="font-bold">Simulação 4Ps</h3>
      <div>
        Nome: <input value={nome} onChange={e=>setNome(e.target.value)} className="border p-1" />
      </div>
      <div>
        Qualidade: <input type="range" min={0} max={100} value={quality} onChange={e=>setQuality(+e.target.value)} /> {quality}
      </div>
      <div>
        Preço: {[1,2,3].map(p=>(<button key={p} onClick={()=>setPrice(p)} className={`m-1 px-2 ${price===p?"bg-indigo-600 text-white":"bg-slate-200"}`}>{p===1?"Baixo":p===2?"Médio":"Alto"}</button>))}
      </div>
      <div>Demanda: {r.demand}</div>
      <div>Receita: ${r.revenue}</div>
      <Button onClick={salvar}>Salvar no Ranking</Button>
    </Card>
  );
}

// ------------------------------ Ranking ------------------------------
function Ranking() {
  const [items, setItems] = useState(()=>JSON.parse(localStorage.getItem("ranking")||"[]"));

  function refresh(){ setItems(JSON.parse(localStorage.getItem("ranking")||"[]")); }
  function clearAll(){ localStorage.removeItem("ranking"); setItems([]); }
  function exportCSV(){
    const header = ["data","nome","qualidade","preco","demanda","receita"]; 
    const lines = [header.join(",")].concat(
      items.map(r=>[
        new Date(r.id).toISOString(), JSON.stringify(r.nome), r.qualidade, r.preco, r.demand, r.revenue
      ].join(","))
    );
    downloadText("ranking_mercadologia.csv", lines.join("\n"));
  }

  return (
    <Card>
      <h3 className="font-bold mb-2">Ranking</h3>
      {items.length===0 && <p>Nenhum registro salvo.</p>}
      <ul>
        {items.map(r=>(<li key={r.id}>{r.nome}: Q{r.qualidade}/P{r.preco} – Demanda {r.demand}, Receita ${r.revenue}</li>))}
      </ul>
      <div className="flex gap-2 mt-2">
        <Button onClick={refresh}>Atualizar</Button>
        <Button onClick={exportCSV}>Exportar CSV</Button>
        <Button onClick={clearAll}>Limpar</Button>
      </div>
    </Card>
  );
}

// ------------------------------ Testes rápidos ------------------------------
function runTests(){
  const results = [];
  const ok = (name, cond, info="") => results.push({name, cond, info});
  // Teste 1: U1Q1 deve ter 4 opções e índice válido
  try {
    const q = QUIZ_BANK.U1[0];
    ok("U1Q1 com 4 opções", q.options.length === 4);
    ok("U1Q1 índice válido", q.correctIndex >= 0 && q.correctIndex < q.options.length);
    ok("U1Q1 sem barra invertida na última opção", !/\\$/.test(q.options[3]));
  } catch(e){ ok("Estrutura do QUIZ", false, e.message); }
  // Teste 2: Qualidade maior deve aumentar demanda
  try {
    const a = computeResult({quality:40, price:2});
    const b = computeResult({quality:80, price:2});
    ok("Qualidade↑ ⇒ Demanda↑", b.demand > a.demand, `${a.demand} -> ${b.demand}`);
  } catch(e){ ok("Cálculo demanda por qualidade", false, e.message); }
  // Teste 3: Preço maior deve reduzir demanda
  try {
    const a = computeResult({quality:70, price:1});
    const b = computeResult({quality:70, price:3});
    ok("Preço↑ ⇒ Demanda↓", b.demand < a.demand, `${a.demand} -> ${b.demand}`);
  } catch(e){ ok("Cálculo demanda por preço", false, e.message); }
  return results;
}

function Testes() {
  const [res] = useState(()=>runTests());
  const pass = res.filter(r=>r.cond).length;
  return (
    <Card>
      <h3 className="font-bold mb-2">Testes</h3>
      <div className="text-sm mb-2">{pass} / {res.length} testes passaram</div>
      <ul className="text-sm list-disc ml-5">
        {res.map((r,i)=>(<li key={i}>{r.cond?"✅":"❌"} {r.name} {r.info?`(${r.info})`:""}</li>))}
      </ul>
    </Card>
  );
}

// ------------------------------ App ------------------------------
export default function App(){
  const [tab,setTab]=useState("sim");
  return (
    <div className="max-w-2xl mx-auto p-3">
      <nav className="flex gap-2 mb-3">
        <Button onClick={()=>setTab("sim")}>Simulação</Button>
        <Button onClick={()=>setTab("quiz")}>Quiz</Button>
        <Button onClick={()=>setTab("rank")}>Ranking</Button>
        <Button onClick={()=>setTab("tests")}>Testes</Button>
      </nav>
      {tab==="sim" && <Simulacao/>}
      {tab==="quiz" && <Quiz/>}
      {tab==="rank" && <Ranking/>}
      {tab==="tests" && <Testes/>}
    </div>
  );
}
